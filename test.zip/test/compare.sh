#!/bin/bash
gcc ./data.c -o data
gcc ./std.c -o std
cd .. 
make 
cd test
while true; do
	./data > data.in
	../multimod-32 < data.in > main.out
	./std < data.in > std.out
if diff std.out main.out ; then
	printf AC
else 
	echo WA
	exit 0
fi
done
