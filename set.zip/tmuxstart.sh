#!/bin/bash
session="webpack-ts"

tmux new-session -d -s $session

window=0
tmux new-window -t $session:$window -n 'ics2022'
tmux send-keys -t $session:$window 'cd ics2022'

window=1
tmux new-window -t $session:$window -n 'nemu'
tmux send-keys -t $session:$window 'cd ~/ics2022/nemu'

window=2
tmux new-window -t $session:$window -n 'home'

tmux attach-session -t $session

