#include "trap.h"

char buf[128];

int main() {
	printf(buf, "%s", "Hello world!\n");
	

	return 0;
}
